name = 'depth_stat'

from .depth_stat import SeqDepth